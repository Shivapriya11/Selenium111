
public class HelloWorld 
{
	String SayHello()
	{
		return "Hello World!";
	}
	
}
